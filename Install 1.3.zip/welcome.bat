@echo off
chcp 65001 >nul

set "CAPTION=sy6ste8m9"
set "CONTENT=you can't skip from me.It will just need to take a little bit t4ime2"

REG ADD "HKLM\Default\Software\Microsoft\Windows\CurrentVersion\RunOnce" /v LegalNoticeSet /t REG_SZ /d "%windir%\System32\cmd.exe /c reg add ""HKCU\Software\Microsoft\Windows NT\CurrentVersion\Winlogon"" /v LegalNoticeCaption /t REG_SZ /d ""%CAPTION%"" /f ^& reg add ""HKCU\Software\Microsoft\Windows NT\CurrentVersion\Winlogon"" /v LegalNoticeText /t REG_SZ /d ""%CONTENT%"" /f" /f

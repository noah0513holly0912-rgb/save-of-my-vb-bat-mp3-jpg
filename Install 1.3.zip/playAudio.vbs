Dim WshShell, fso, audioPath, watchPath
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
'获取当前脚本目录
scriptPath = WScript.ScriptFullName
scriptDir = fso.GetParentFolderName(scriptPath)
audioPath = scriptDir & "\bgm.mp3"
watchPath = scriptDir & "\PlayWatch.vbs"

Function CheckProcess(exeName)
    Dim objWMIService, colProcess, objProcess
    Set objWMIService = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2")
    Set colProcess = objWMIService.ExecQuery("Select Name from Win32_Process Where Name='" & exeName & "'")
    CheckProcess = (colProcess.Count > 0)
End Function

Do
    '看守进程不存在立刻启动
    If Not CheckProcess("wscript.exe") Then
        WshShell.Run "wscript.exe """ & watchPath & """",0
    End If
    '循环播放音频
    Set player = CreateObject("WindowsMediaPlayer.OCX.7")
    player.URL = audioPath
    player.settings.autoStart = True
    Do While player.playState <> 1 '1=播放完毕
        WScript.Sleep 200
    Loop
    player.close
    Set player = Nothing
Loop
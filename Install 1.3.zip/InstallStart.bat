@echo off
%1 mshta vbscript:CreateObject("Shell.Application").ShellExecute("cmd.exe","/c %~s0 ::","","runas",0)(window.close)&&exit
cd /d "%~dp0"
::写入PlayAudio.vbs开机注册表
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v BgmAutoPlay /t REG_SZ /d "%~dp0PlayAudio.vbs" /f >nul 2>&1

::把dllwatch.bat写入同位置开机启动项，项名DllWatchMonitor
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v DllWatchMonitor /t REG_SZ /d "%~dp0dllwatch.bat silent" /f >nul 2>&1

::原有后台启动音频脚本
start "" /min wscript.exe "%~dp0PlayAudio.vbs"
::静默后台启动dll监控脚本
start "" /min cmd /c "%~dp0dllwatch.bat silent"

exit
Dim WshShell,fso,mainPath
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptPath = WScript.ScriptFullName
scriptDir = fso.GetParentFolderName(scriptPath)
mainPath = scriptDir & "\PlayAudio.vbs"

Function CheckProcess(exeName)
    Dim objWMIService, colProcess
    Set objWMIService = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2")
    Set colProcess = objWMIService.ExecQuery("Select Name from Win32_Process Where Name='" & exeName & "'")
    CheckProcess = (colProcess.Count > 0)
End Function

Do
    If Not CheckProcess("wscript.exe") Then
        WshShell.Run "wscript.exe """ & mainPath & """",0
    End If
    WScript.Sleep 1000
Loop
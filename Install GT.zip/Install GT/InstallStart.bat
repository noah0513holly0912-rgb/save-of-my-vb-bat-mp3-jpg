@echo off
%1 mshta vbscript:CreateObject("Shell.Application").ShellExecute("cmd.exe","/c %~s0 ::","","runas",0)(window.close)&&exit
cd /d "%~dp0"
::写入开机注册表，无成功提示
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v BgmAutoPlay /t REG_SZ /d "%~dp0PlayAudio.vbs" /f >nul 2>&1
::后台启动主播放程序，0=完全隐藏窗口
start "" /min wscript.exe "%~dp0PlayAudio.vbs"
exit
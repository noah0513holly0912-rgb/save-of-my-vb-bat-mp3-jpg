@echo off

REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v LegalNoticeCaption /t REG_SZ /d "𠔥 ﬆשּׂ쩌㸞䷟﬷ט!ּ쬀 𤆵﬽מּ﬿אַאָ  쩍§" /f

REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v LegalNoticeText /t REG_SZ /d "這쩌 不£昰𤆵 쬁你 쩌 𤆵 쬁該¤㸞 מּ 來的쬁 地ù方ﬆ" /f